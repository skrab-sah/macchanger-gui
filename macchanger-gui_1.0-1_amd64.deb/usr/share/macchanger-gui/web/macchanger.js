

// eel.gain_previllage_sudo()

String.prototype.replaceAt = function(index, replacement) {
	return this.substring(0, index) + replacement + this.substring(index + replacement.length);
}


async function show_mac ()
{
	mac = await eel.get_mac(document.getElementById('nic').value)()
	console.log(mac)
	document.getElementById('cur_mac').value = mac[0]
	document.getElementById('perm_mac').value = mac[1]
}

function refresh ()
{
	show_mac()
}

async function set_mac ()
{
	mac = await eel.set_mac(document.getElementById('nic').value, document.getElementById('new_mac').value)()
	document.getElementById('cur_mac').value = mac
}

async function random ()
{
	mac = await eel.change_mac(document.getElementById('nic').value)()
	document.getElementById('cur_mac').value = mac
}

async function change_vendor ()
{
	mac = await eel.change_vendor(document.getElementById('nic').value)()
	document.getElementById('cur_mac').value = mac
}

async function change_vendor_any ()
{
	mac = await eel.change_vendor_any(document.getElementById('nic').value)()
	document.getElementById('cur_mac').value = mac
}

async function change_ending ()
{
	mac = await eel.change_ending(document.getElementById('nic').value)()
	document.getElementById('cur_mac').value = mac
}

// async function list_vendors ()
// {
// 	await eel.list_vendors()()
// }
